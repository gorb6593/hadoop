package mapred.exam.air;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class AirMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
	Text outputKey = new Text();
	static final IntWritable outputval = new IntWritable(1);
	@Override
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		if(key.get()>0) {
			String[] line = value.toString().split(",");
			if(line!=null & line.length>0) {
				outputKey.set(line[1]);
				int result = 0;
				String NA = "NA";
				if(!line[15].equals(NA)) {
					 result = Integer.parseInt(line[15]);
				}									
				if(result>0) {
					context.write(outputKey, outputval);
				}
			}
		}		
	}	
}
